<?php

namespace Illuminate\Cache\Events;

class CacheMissed extends CacheEvent
{
    //
}
